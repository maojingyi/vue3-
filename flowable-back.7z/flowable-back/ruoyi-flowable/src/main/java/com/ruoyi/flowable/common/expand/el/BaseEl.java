package com.ruoyi.flowable.common.expand.el;

/**
 * 扩展表达式
 *
 * @author Tony
 * @date 2023-03-04 09:10
 */
public interface BaseEl {

}

