package com.ruoyi.flowable.common.expand.function;

import lombok.extern.slf4j.Slf4j;
import org.flowable.common.engine.api.variable.VariableContainer;
import org.flowable.common.engine.impl.el.function.AbstractFlowableVariableExpressionFunction;

/**
 * 表达式函数：实现逻辑用java
 *
 * @author Tony
 * @date 2023-03-04 09:10
 */
@Slf4j
public class ExpressionLanguageJavaFunction extends AbstractFlowableVariableExpressionFunction{

	public ExpressionLanguageJavaFunction() {
		super("test");
	}

	public static String test(VariableContainer variableContainer, String variableName) {
		log.info("开始查询表达式变量值,test");
		Object variableValue = getVariableValue(variableContainer, variableName);
		return variableValue.toString();
	}

}
