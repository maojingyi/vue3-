package com.ruoyi.flowable.config;

import com.ruoyi.flowable.common.expand.el.BaseEl;
import com.ruoyi.flowable.common.expand.function.ExpressionLanguageJavaFunction;
import org.flowable.engine.impl.db.DbIdGenerator;
import org.flowable.spring.SpringProcessEngineConfiguration;
import org.flowable.spring.boot.EngineConfigurationConfigurer;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * 扩展流程配置
 * @author Tony
 * @date 2022-12-26 10:24
 */
@Configuration
public class FlowableConfig implements EngineConfigurationConfigurer<SpringProcessEngineConfiguration> {
    @Override
    public void configure(SpringProcessEngineConfiguration engineConfiguration) {
        engineConfiguration.setActivityFontName("宋体");
        engineConfiguration.setLabelFontName("宋体");
        engineConfiguration.setAnnotationFontName("宋体");
        engineConfiguration.setIdGenerator(new DbIdGenerator());
        //如果是达蒙设置为oracle
        //processEngineConfiguration.setDatabaseType("oracle");

        // 配置历史数据清洗
//        engineConfiguration.setEnableHistoryCleaning(true);
//        engineConfiguration.setHistoryCleaningTimeCycleConfig("0 0 1 * * ?");
//        engineConfiguration.setCleanInstancesEndedAfter(Duration.ofDays(1));

        // 配置表达式
        // initExpressFunction(engineConfiguration);
        // //注册el表达式函数
        // initElBeans(engineConfiguration);
    }

    /**
     * 注册 flowable el bean
     */
    public void initElBeans(SpringProcessEngineConfiguration springProcessEngineConfiguration) {
        Map<String, BaseEl> map = springProcessEngineConfiguration.getApplicationContext().getBeansOfType(BaseEl.class);
        Map<Object, Object> beansMap = new HashMap<>(map);
        springProcessEngineConfiguration.setBeans(beansMap);
        springProcessEngineConfiguration.buildProcessEngine();
    }

    /**
     * 配置扩展表达式解析方法
     */
    private void initExpressFunction(SpringProcessEngineConfiguration springProcessEngineConfiguration) {
        springProcessEngineConfiguration.initFunctionDelegates();
        springProcessEngineConfiguration.getFlowableFunctionDelegates().add(new ExpressionLanguageJavaFunction());
    }
}
