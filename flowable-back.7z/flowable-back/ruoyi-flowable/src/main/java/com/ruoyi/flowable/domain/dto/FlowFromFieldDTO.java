package com.ruoyi.flowable.domain.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Tony
 * @date 2021/3/31 23:20
 */
@Data
public class FlowFromFieldDTO implements Serializable {

    private Object fields;
}
