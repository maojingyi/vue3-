package com.ruoyi.flowable.listener;

import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class TaskAsigneeListener implements TaskListener {
    /**
     * 复写TaskListener
     */
    @Override
    public void notify(DelegateTask delegateTask) {
        String assignee = (String) delegateTask.getVariable("assignee ");
        delegateTask.setAssignee(assignee);
      //  taskService.setAssignee(delegateTask.getId(), startUserId);

    }
}
