package com.ruoyi.annualmeetingplans.controller;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.core.domain.model.LoginUser;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.annualmeetingplans.domain.AnnualMeetingPlans;
import com.ruoyi.annualmeetingplans.service.IAnnualMeetingPlansService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.web.multipart.MultipartFile;

/**
 * AnnualMeetingPlansController
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
@RestController
@RequestMapping("/annualmeetingplans/Plans")
public class AnnualMeetingPlansController extends BaseController
{
    @Autowired
    private IAnnualMeetingPlansService annualMeetingPlansService;
    @Autowired
    private IAnnualMeetingPlansService userService;
    /**
     * 查询AnnualMeetingPlans列表
     */
    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:list')")
    @GetMapping("/list")
    public TableDataInfo list(AnnualMeetingPlans annualMeetingPlans)
    {
        startPage();
        List<AnnualMeetingPlans> list = annualMeetingPlansService.selectAnnualMeetingPlansList(annualMeetingPlans);
        return getDataTable(list);
    }

    /**
     * 导出AnnualMeetingPlans列表
     */
    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:export')")
    @Log(title = "AnnualMeetingPlans", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, AnnualMeetingPlans annualMeetingPlans)
    {
        List<AnnualMeetingPlans> list = annualMeetingPlansService.selectAnnualMeetingPlansList(annualMeetingPlans);
        ExcelUtil<AnnualMeetingPlans> util = new ExcelUtil<AnnualMeetingPlans>(AnnualMeetingPlans.class);
        util.exportExcel(response, list, "AnnualMeetingPlans数据");
    }

    /**
     * 获取AnnualMeetingPlans详细信息
     */
    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:query')")
    @GetMapping(value = "/{planId}")
    public AjaxResult getInfo(@PathVariable("planId") Long planId)
    {
        return success(annualMeetingPlansService.selectAnnualMeetingPlansByPlanId(planId));
    }

    /**
     * 新增AnnualMeetingPlans
     */
    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:add')")
    @Log(title = "AnnualMeetingPlans", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody AnnualMeetingPlans annualMeetingPlans)
    {
        return toAjax(annualMeetingPlansService.insertAnnualMeetingPlans(annualMeetingPlans));
    }

    /**
     * 修改AnnualMeetingPlans
     */
    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:edit')")
    @Log(title = "AnnualMeetingPlans", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody AnnualMeetingPlans annualMeetingPlans)
    {
        return toAjax(annualMeetingPlansService.updateAnnualMeetingPlans(annualMeetingPlans));
    }

    /**
     * 删除AnnualMeetingPlans
     */
    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:remove')")
    @Log(title = "AnnualMeetingPlans", businessType = BusinessType.DELETE)
	@DeleteMapping("/{planIds}")
    public AjaxResult remove(@PathVariable Long[] planIds)
    {
        return toAjax(annualMeetingPlansService.deleteAnnualMeetingPlansByPlanIds(planIds));
    }



    /**
     * 上传年度会议计划
     */
    //@Anonymous
    @Log(title = "AnnualMeetingPlans", businessType = BusinessType.IMPORT)
    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:import')")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file, boolean updateSupport) throws Exception
    {
        ExcelUtil<AnnualMeetingPlans> util = new ExcelUtil<AnnualMeetingPlans>(AnnualMeetingPlans.class);
        List<AnnualMeetingPlans> userList = util.importExcel(file.getInputStream(),2);
        System.out.println("1111111111111111111111111111111111111111");
        System.out.println(userList);
        LoginUser loginUser = getLoginUser();
        String operName = loginUser.getUsername();
        String message = userService.importUser(userList, updateSupport, operName);
        return AjaxResult.success(message);
    }
    /**
     * 下载模板
     */
//    @PreAuthorize("@ss.hasPermi('annualmeetingplans:Plans:importTemplate')")
//    @GetMapping("/importTemplate")
//
//    public AjaxResult importTemplate(HttpServletResponse response, AnnualMeetingPlans annualMeetingPlans)
//    {
//        String fileName = "模板.xlsx";
//        String realPath = String.valueOf(getClass().getProtectionDomain().getCodeSource().getLocation()).replace("file:","");
//        // 文件在项目中路径
//        String filePath =realPath +"/filetemplate/"+ fileName;
//        FileInputStream fileInputStream = null;
//        XSSFWorkbook workBook = null;
//        OutputStream out = null;
//        try {
//            fileInputStream = new FileInputStream(filePath);  //  输入流
//            workBook=new XSSFWorkbook(fileInputStream);
//            XSSFSheet sheet0 = workBook.getSheetAt(0);
//            // 写入数据
//            List<AnnualMeetingPlans> list = annualMeetingPlansService.selectAnnualMeetingPlansList(annualMeetingPlans);
//
//                // 索引从0开始
//                XSSFRow row = sheet0.createRow(3);
//                row.createCell(0).setCellValue(list.get(i).getId());
//                row.createCell(1).setCellValue(list.get(i).getAuditCode());
//                row.createCell(2).setCellValue(list.get(i).getAuditMatter());
//                row.createCell(3).setCellValue(list.get(i).getArchivesId());
//                row.createCell(4).setCellValue(list.get(i).getAuditProcessRecord());
//                row.createCell(5).setCellValue(list.get(i).getAuditProcessResult());
//
//            for (int i = 0; i < 5; i++) {
//                XSSFRow row = sheet1.createRow(3 + i);
//                row.createCell(0).setCellValue(i);
//                row.createCell(1).setCellValue(i);
//                row.createCell(2).setCellValue(i);
//                row.createCell(3).setCellValue(i);
//                row.createCell(4).setCellValue(i);
//                row.createCell(5).setCellValue(i);
//            }
//            ExcelUtil excelUtil = new ExcelUtil(null);
//            out = new FileOutputStream(excelUtil.getAbsoluteFile(fileName));
//            workBook.write(out);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }finally {
//            if (null != fileInputStream) {
//                try {
//                    fileInputStream.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//            if (null != out) {
//                try {
//                    out.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//            if (null != workBook) {
//                try {
//                    workBook.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//        return AjaxResult.success(fileName);
//    }
//
//
//
//
//
//
//
//        ExcelUtil<AnnualMeetingPlans> util = new ExcelUtil<AnnualMeetingPlans>(AnnualMeetingPlans.class);
//         util.importTemplateExcel(response, "用户数据");
//    }


}



