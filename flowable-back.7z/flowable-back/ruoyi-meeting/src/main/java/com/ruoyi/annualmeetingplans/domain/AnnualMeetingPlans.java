package com.ruoyi.annualmeetingplans.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * AnnualMeetingPlans对象 Annual_Meeting_Plans
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public class AnnualMeetingPlans extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 会议id */
    private Long planId;

    /** 年份 */
    @Excel(name = "年份")
    private Long year;

    /** 主办部门 */
    @Excel(name = "主办部门")
    private String department;

    /** 会议名称 */
    @Excel(name = "会议名称")
    private String meetingName;

    /** 会议类别 */
    @Excel(name = "会议类别",readConverterExp = "2=二类会议,3=三类会议,4=四类会议")
    private String meetingType;

    /** 会议数量 */
    @Excel(name = "会议数量")
    private Long meetingCount;

    /** 举办时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "举办时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date meetingDate;

    /** 会期  */
    @Excel(name = "会期")
    private Long howManydays;

    /** 主题内容 */
   // @Excel(name = "会议内容")
    @Excel(name = "会议内容/主题")
    private String meetingContext;

    /** 参会对象 */
    @Excel(name = "参会对象")
    private String meetingObject;

    /** 参会人数 */
    @Excel(name = "参会人数")
    private Long numcount;

    /** 会议召开状态 */
    @Excel(name = "会议召开状态",readConverterExp = "1=已召开,2=待召开,3=已取消")
    private String status;

    public void setPlanId(Long planId) 
    {
        this.planId = planId;
    }

    public Long getPlanId() 
    {
        return planId;
    }
    public void setYear(Long year) 
    {
        this.year = year;
    }

    public Long getYear() 
    {
        return year;
    }
    public void setDepartment(String department) 
    {
        this.department = department;
    }

    public String getDepartment() 
    {
        return department;
    }
    public void setMeetingName(String meetingName) 
    {
        this.meetingName = meetingName;
    }

    public String getMeetingName() 
    {
        return meetingName;
    }
    public void setMeetingType(String meetingType) 
    {
        this.meetingType = meetingType;
    }

    public String getMeetingType() 
    {
        return meetingType;
    }
    public void setMeetingCount(Long meetingCount) 
    {
        this.meetingCount = meetingCount;
    }

    public Long getMeetingCount() 
    {
        return meetingCount;
    }
    public void setMeetingDate(Date meetingDate) 
    {
        this.meetingDate = meetingDate;
    }

    public Date getMeetingDate() 
    {
        return meetingDate;
    }
    public void setHowManydays(Long howManydays) 
    {
        this.howManydays = howManydays;
    }

    public Long getHowManydays() 
    {
        return howManydays;
    }
    public void setMeetingContext(String meetingContext) 
    {
        this.meetingContext = meetingContext;
    }

    public String getMeetingContext() 
    {
        return meetingContext;
    }
    public void setMeetingObject(String meetingObject) 
    {
        this.meetingObject = meetingObject;
    }

    public String getMeetingObject() 
    {
        return meetingObject;
    }
    public void setNumcount(Long numcount) 
    {
        this.numcount = numcount;
    }

    public Long getNumcount() 
    {
        return numcount;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("planId", getPlanId())
            .append("year", getYear())
            .append("department", getDepartment())
            .append("meetingName", getMeetingName())
            .append("meetingType", getMeetingType())
            .append("meetingCount", getMeetingCount())
            .append("meetingDate", getMeetingDate())
            .append("howManydays", getHowManydays())
            .append("meetingContext", getMeetingContext())
            .append("meetingObject", getMeetingObject())
            .append("numcount", getNumcount())
            .append("status", getStatus())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .toString();
    }
}
