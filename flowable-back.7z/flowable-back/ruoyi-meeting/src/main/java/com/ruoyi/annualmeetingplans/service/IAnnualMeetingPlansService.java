package com.ruoyi.annualmeetingplans.service;

import java.util.List;
import com.ruoyi.annualmeetingplans.domain.AnnualMeetingPlans;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.bean.BeanValidators;

/**
 * AnnualMeetingPlansService接口
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public interface IAnnualMeetingPlansService 
{
    /**
     * 查询AnnualMeetingPlans
     * 
     * @param planId AnnualMeetingPlans主键
     * @return AnnualMeetingPlans
     */
    public AnnualMeetingPlans selectAnnualMeetingPlansByPlanId(Long planId);

    /**
     * 查询AnnualMeetingPlans列表
     * 
     * @param annualMeetingPlans AnnualMeetingPlans
     * @return AnnualMeetingPlans集合
     */
    public List<AnnualMeetingPlans> selectAnnualMeetingPlansList(AnnualMeetingPlans annualMeetingPlans);

    /**
     * 新增AnnualMeetingPlans
     * 
     * @param annualMeetingPlans AnnualMeetingPlans
     * @return 结果
     */
    public int insertAnnualMeetingPlans(AnnualMeetingPlans annualMeetingPlans);

    /**
     * 修改AnnualMeetingPlans
     * 
     * @param annualMeetingPlans AnnualMeetingPlans
     * @return 结果
     */
    public int updateAnnualMeetingPlans(AnnualMeetingPlans annualMeetingPlans);

    /**
     * 批量删除AnnualMeetingPlans
     * 
     * @param planIds 需要删除的AnnualMeetingPlans主键集合
     * @return 结果
     */
    public int deleteAnnualMeetingPlansByPlanIds(Long[] planIds);

    /**
     * 删除AnnualMeetingPlans信息
     * 
     * @param planId AnnualMeetingPlans主键
     * @return 结果
     */
    public int deleteAnnualMeetingPlansByPlanId(Long planId);



    public String importUser(List<AnnualMeetingPlans> userList, boolean updateSupport, String operName);



}
