package com.ruoyi.annualmeetingplans.service.impl;

import java.util.List;

import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.annualmeetingplans.mapper.AnnualMeetingPlansMapper;
import com.ruoyi.annualmeetingplans.domain.AnnualMeetingPlans;
import com.ruoyi.annualmeetingplans.service.IAnnualMeetingPlansService;

/**
 * AnnualMeetingPlansService业务层处理
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
@Service
public class AnnualMeetingPlansServiceImpl implements IAnnualMeetingPlansService 
{
    @Autowired
    private AnnualMeetingPlansMapper annualMeetingPlansMapper;

    /**
     * 查询AnnualMeetingPlans
     * 
     * @param planId AnnualMeetingPlans主键
     * @return AnnualMeetingPlans
     */
    @Override
    public AnnualMeetingPlans selectAnnualMeetingPlansByPlanId(Long planId)
    {
        return annualMeetingPlansMapper.selectAnnualMeetingPlansByPlanId(planId);
    }

    /**
     * 查询AnnualMeetingPlans列表
     * 
     * @param annualMeetingPlans AnnualMeetingPlans
     * @return AnnualMeetingPlans
     */
    @Override
    public List<AnnualMeetingPlans> selectAnnualMeetingPlansList(AnnualMeetingPlans annualMeetingPlans)
    {
        return annualMeetingPlansMapper.selectAnnualMeetingPlansList(annualMeetingPlans);
    }

    /**
     * 新增AnnualMeetingPlans
     * 
     * @param annualMeetingPlans AnnualMeetingPlans
     * @return 结果
     */
    @Override
    public int insertAnnualMeetingPlans(AnnualMeetingPlans annualMeetingPlans)
    {
        annualMeetingPlans.setCreateTime(DateUtils.getNowDate());
        return annualMeetingPlansMapper.insertAnnualMeetingPlans(annualMeetingPlans);
    }

    /**
     * 修改AnnualMeetingPlans
     * 
     * @param annualMeetingPlans AnnualMeetingPlans
     * @return 结果
     */
    @Override
    public int updateAnnualMeetingPlans(AnnualMeetingPlans annualMeetingPlans)
    {
        annualMeetingPlans.setUpdateTime(DateUtils.getNowDate());
        return annualMeetingPlansMapper.updateAnnualMeetingPlans(annualMeetingPlans);
    }

    /**
     * 批量删除AnnualMeetingPlans
     * 
     * @param planIds 需要删除的AnnualMeetingPlans主键
     * @return 结果
     */
    @Override
    public int deleteAnnualMeetingPlansByPlanIds(Long[] planIds)
    {
        return annualMeetingPlansMapper.deleteAnnualMeetingPlansByPlanIds(planIds);
    }

    /**
     * 删除AnnualMeetingPlans信息
     * 
     * @param planId AnnualMeetingPlans主键
     * @return 结果
     */
    @Override
    public int deleteAnnualMeetingPlansByPlanId(Long planId)
    {
        return annualMeetingPlansMapper.deleteAnnualMeetingPlansByPlanId(planId);
    }

    @Override
    public String importUser(List<AnnualMeetingPlans> userList, boolean updateSupport, String operName) {
        if (StringUtils.isNull(userList) || userList.size() == 0)
        {
            throw new ServiceException("导入用户数据不能为空！");

        }
        int successNum = 0;
        int failureNum = 0;
        StringBuilder successMsg = new StringBuilder();
        StringBuilder failureMsg = new StringBuilder();
        List<AnnualMeetingPlans> existList = selectAnnualMeetingPlansList(null);
        for (AnnualMeetingPlans user : userList)
        {
            try {

                boolean userFlag = false;
                //
                for (AnnualMeetingPlans entry : existList) {
                    if ((entry.getMeetingName().equals(user.getMeetingName()))&&(entry.getYear().equals(user.getYear())&&(entry.getDepartment().equals(user.getDepartment())))){
                        user.setPlanId(entry.getPlanId());
                        userFlag = true;
                        break;
                    }
                }
                if (!userFlag) {
                    insertAnnualMeetingPlans(user);
                    successNum++;
                    successMsg.append("<br/>" + successNum + "、数据 " + user.getMeetingName() + " 导入成功");
                } else if (!updateSupport) {
                    updateAnnualMeetingPlans(user);
                    successNum++;
                    successMsg.append("<br/>" + successNum + "、数据 " + user.getMeetingName() + " 更新成功");
                } else {
                    failureNum++;
                    failureMsg.append("<br/>" + failureNum + "、数据 " + user.getMeetingName() + " 已存在");

                }
            }catch (Exception e)
            {
                failureNum++;
                String msg = "<br/>" + failureNum + "、账号 " +  " 导入失败：";
                failureMsg.append(msg + e.getMessage());
                //log.error(msg, e);
            }
        }
        if (failureNum > 0)
        {
            failureMsg.insert(0, "很抱歉，导入失败！共 " + failureNum + " 条数据格式不正确，错误如下：");
            return failureMsg.toString();

            //throw new CustomException(failureMsg.toString());
        }
        else
        {
            successMsg.insert(0, "恭喜您，数据已全部导入成功！共 " + successNum + " 条，数据如下：");
        }
        return successMsg.toString();
    }

}
