package com.ruoyi.meeting.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * Meeting对象 Meeting
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public class Meeting extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 会议编号 */
    private Long meetingId;

    /** 会议名称 */
    @Excel(name = "会议名称")
    private String meetingName;

    /** 会议举办时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "会议举办时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date meetingDate;

    /** 会议主持人 */
    @Excel(name = "会议主持人")
    private String meetingHost;

    /** 会议着装要求 */
    @Excel(name = "会议着装要求")
    private String dressType;

    /** 会议正式通知 */
    @Excel(name = "会议正式通知")
    private String meetingNotice;

    /** 会议类型 */
    @Excel(name = "会议类型")
    private String meetingType;

    /** 会议室 */
    @Excel(name = "会议室")
    private String meetingRoom;

    /** 会议议程 */
    @Excel(name = "会议议程")
    private String agenda;

    /** 参会人员列表 */
    @Excel(name = "参会人员列表")
    private String participants;

    /** 会议召开状态 */
    @Excel(name = "会议召开状态")
    private String status;

    /** 会议持续时间
 */
    @Excel(name = "会议持续时间 ")
    private Long meetingDuration;

    public void setMeetingId(Long meetingId) 
    {
        this.meetingId = meetingId;
    }

    public Long getMeetingId() 
    {
        return meetingId;
    }
    public void setMeetingName(String meetingName) 
    {
        this.meetingName = meetingName;
    }

    public String getMeetingName() 
    {
        return meetingName;
    }
    public void setMeetingDate(Date meetingDate) 
    {
        this.meetingDate = meetingDate;
    }

    public Date getMeetingDate() 
    {
        return meetingDate;
    }
    public void setMeetingHost(String meetingHost) 
    {
        this.meetingHost = meetingHost;
    }

    public String getMeetingHost() 
    {
        return meetingHost;
    }
    public void setDressType(String dressType) 
    {
        this.dressType = dressType;
    }

    public String getDressType() 
    {
        return dressType;
    }
    public void setMeetingNotice(String meetingNotice) 
    {
        this.meetingNotice = meetingNotice;
    }

    public String getMeetingNotice() 
    {
        return meetingNotice;
    }
    public void setMeetingType(String meetingType) 
    {
        this.meetingType = meetingType;
    }

    public String getMeetingType() 
    {
        return meetingType;
    }
    public void setMeetingRoom(String meetingRoom) 
    {
        this.meetingRoom = meetingRoom;
    }

    public String getMeetingRoom() 
    {
        return meetingRoom;
    }
    public void setAgenda(String agenda) 
    {
        this.agenda = agenda;
    }

    public String getAgenda() 
    {
        return agenda;
    }
    public void setParticipants(String participants) 
    {
        this.participants = participants;
    }

    public String getParticipants() 
    {
        return participants;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }
    public void setMeetingDuration(Long meetingDuration) 
    {
        this.meetingDuration = meetingDuration;
    }

    public Long getMeetingDuration() 
    {
        return meetingDuration;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("meetingId", getMeetingId())
            .append("meetingName", getMeetingName())
            .append("meetingDate", getMeetingDate())
            .append("meetingHost", getMeetingHost())
            .append("dressType", getDressType())
            .append("meetingNotice", getMeetingNotice())
            .append("meetingType", getMeetingType())
            .append("meetingRoom", getMeetingRoom())
            .append("agenda", getAgenda())
            .append("participants", getParticipants())
            .append("status", getStatus())
            .append("meetingDuration", getMeetingDuration())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .toString();
    }
}
