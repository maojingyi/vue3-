package com.ruoyi.meeting.service;

import java.util.List;
import com.ruoyi.meeting.domain.Meeting;

/**
 * MeetingService接口
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public interface IMeetingService 
{
    /**
     * 查询Meeting
     * 
     * @param meetingId Meeting主键
     * @return Meeting
     */
    public Meeting selectMeetingByMeetingId(Long meetingId);

    /**
     * 查询Meeting列表
     * 
     * @param meeting Meeting
     * @return Meeting集合
     */
    public List<Meeting> selectMeetingList(Meeting meeting);

    /**
     * 新增Meeting
     * 
     * @param meeting Meeting
     * @return 结果
     */
    public int insertMeeting(Meeting meeting);

    /**
     * 修改Meeting
     * 
     * @param meeting Meeting
     * @return 结果
     */
    public int updateMeeting(Meeting meeting);

    /**
     * 批量删除Meeting
     * 
     * @param meetingIds 需要删除的Meeting主键集合
     * @return 结果
     */
    public int deleteMeetingByMeetingIds(Long[] meetingIds);

    /**
     * 删除Meeting信息
     * 
     * @param meetingId Meeting主键
     * @return 结果
     */
    public int deleteMeetingByMeetingId(Long meetingId);
}
