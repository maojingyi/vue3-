package com.ruoyi.meeting.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.meeting.mapper.MeetingMapper;
import com.ruoyi.meeting.domain.Meeting;
import com.ruoyi.meeting.service.IMeetingService;

/**
 * MeetingService业务层处理
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
@Service
public class MeetingServiceImpl implements IMeetingService 
{
    @Autowired
    private MeetingMapper meetingMapper;

    /**
     * 查询Meeting
     * 
     * @param meetingId Meeting主键
     * @return Meeting
     */
    @Override
    public Meeting selectMeetingByMeetingId(Long meetingId)
    {
        return meetingMapper.selectMeetingByMeetingId(meetingId);
    }

    /**
     * 查询Meeting列表
     * 
     * @param meeting Meeting
     * @return Meeting
     */
    @Override
    public List<Meeting> selectMeetingList(Meeting meeting)
    {
        return meetingMapper.selectMeetingList(meeting);
    }

    /**
     * 新增Meeting
     * 
     * @param meeting Meeting
     * @return 结果
     */
    @Override
    public int insertMeeting(Meeting meeting)
    {
        meeting.setCreateTime(DateUtils.getNowDate());
        return meetingMapper.insertMeeting(meeting);
    }

    /**
     * 修改Meeting
     * 
     * @param meeting Meeting
     * @return 结果
     */
    @Override
    public int updateMeeting(Meeting meeting)
    {
        meeting.setUpdateTime(DateUtils.getNowDate());
        return meetingMapper.updateMeeting(meeting);
    }

    /**
     * 批量删除Meeting
     * 
     * @param meetingIds 需要删除的Meeting主键
     * @return 结果
     */
    @Override
    public int deleteMeetingByMeetingIds(Long[] meetingIds)
    {
        return meetingMapper.deleteMeetingByMeetingIds(meetingIds);
    }

    /**
     * 删除Meeting信息
     * 
     * @param meetingId Meeting主键
     * @return 结果
     */
    @Override
    public int deleteMeetingByMeetingId(Long meetingId)
    {
        return meetingMapper.deleteMeetingByMeetingId(meetingId);
    }
}
