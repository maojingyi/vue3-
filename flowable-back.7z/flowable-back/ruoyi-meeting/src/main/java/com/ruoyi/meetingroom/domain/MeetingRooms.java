package com.ruoyi.meetingroom.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * MeetingRooms对象 Meeting_Rooms
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public class MeetingRooms extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 会议室编号 */
    private Long roomId;

    /** 会议室名称 */
    @Excel(name = "会议室名称")
    private String roomName;

    /** 会议室位置 */
    @Excel(name = "会议室位置")
    private String location;

    /** 容纳人数 */
    @Excel(name = "容纳人数")
    private Long capacity;

    /** 硬件设施描述 */
    @Excel(name = "硬件设施描述")
    private String facilities;

    /** 会议室是否可用 */
    @Excel(name = "会议室是否可用")
    private Integer availability;

    /** 会议室朝向 */
    @Excel(name = "会议室朝向")
    private String head;

    /** 平面图 */
    @Excel(name = "平面图")
    private String pic;

    public void setRoomId(Long roomId) 
    {
        this.roomId = roomId;
    }

    public Long getRoomId() 
    {
        return roomId;
    }
    public void setRoomName(String roomName) 
    {
        this.roomName = roomName;
    }

    public String getRoomName() 
    {
        return roomName;
    }
    public void setLocation(String location) 
    {
        this.location = location;
    }

    public String getLocation() 
    {
        return location;
    }
    public void setCapacity(Long capacity) 
    {
        this.capacity = capacity;
    }

    public Long getCapacity() 
    {
        return capacity;
    }
    public void setFacilities(String facilities) 
    {
        this.facilities = facilities;
    }

    public String getFacilities() 
    {
        return facilities;
    }
    public void setAvailability(Integer availability) 
    {
        this.availability = availability;
    }

    public Integer getAvailability() 
    {
        return availability;
    }
    public void setHead(String head) 
    {
        this.head = head;
    }

    public String getHead() 
    {
        return head;
    }
    public void setPic(String pic) 
    {
        this.pic = pic;
    }

    public String getPic() 
    {
        return pic;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("roomId", getRoomId())
            .append("roomName", getRoomName())
            .append("location", getLocation())
            .append("capacity", getCapacity())
            .append("facilities", getFacilities())
            .append("availability", getAvailability())
            .append("head", getHead())
            .append("pic", getPic())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .toString();
    }
}
