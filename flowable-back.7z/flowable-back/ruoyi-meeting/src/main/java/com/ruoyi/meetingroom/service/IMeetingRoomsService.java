package com.ruoyi.meetingroom.service;

import java.util.List;
import com.ruoyi.meetingroom.domain.MeetingRooms;

/**
 * MeetingRoomsService接口
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public interface IMeetingRoomsService 
{
    /**
     * 查询MeetingRooms
     * 
     * @param roomId MeetingRooms主键
     * @return MeetingRooms
     */
    public MeetingRooms selectMeetingRoomsByRoomId(Long roomId);

    /**
     * 查询MeetingRooms列表
     * 
     * @param meetingRooms MeetingRooms
     * @return MeetingRooms集合
     */
    public List<MeetingRooms> selectMeetingRoomsList(MeetingRooms meetingRooms);

    /**
     * 新增MeetingRooms
     * 
     * @param meetingRooms MeetingRooms
     * @return 结果
     */
    public int insertMeetingRooms(MeetingRooms meetingRooms);

    /**
     * 修改MeetingRooms
     * 
     * @param meetingRooms MeetingRooms
     * @return 结果
     */
    public int updateMeetingRooms(MeetingRooms meetingRooms);

    /**
     * 批量删除MeetingRooms
     * 
     * @param roomIds 需要删除的MeetingRooms主键集合
     * @return 结果
     */
    public int deleteMeetingRoomsByRoomIds(Long[] roomIds);

    /**
     * 删除MeetingRooms信息
     * 
     * @param roomId MeetingRooms主键
     * @return 结果
     */
    public int deleteMeetingRoomsByRoomId(Long roomId);
}
