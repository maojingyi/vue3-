package com.ruoyi.meetingroom.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.meetingroom.mapper.MeetingRoomsMapper;
import com.ruoyi.meetingroom.domain.MeetingRooms;
import com.ruoyi.meetingroom.service.IMeetingRoomsService;

/**
 * MeetingRoomsService业务层处理
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
@Service
public class MeetingRoomsServiceImpl implements IMeetingRoomsService 
{
    @Autowired
    private MeetingRoomsMapper meetingRoomsMapper;

    /**
     * 查询MeetingRooms
     * 
     * @param roomId MeetingRooms主键
     * @return MeetingRooms
     */
    @Override
    public MeetingRooms selectMeetingRoomsByRoomId(Long roomId)
    {
        return meetingRoomsMapper.selectMeetingRoomsByRoomId(roomId);
    }

    /**
     * 查询MeetingRooms列表
     * 
     * @param meetingRooms MeetingRooms
     * @return MeetingRooms
     */
    @Override
    public List<MeetingRooms> selectMeetingRoomsList(MeetingRooms meetingRooms)
    {
        return meetingRoomsMapper.selectMeetingRoomsList(meetingRooms);
    }

    /**
     * 新增MeetingRooms
     * 
     * @param meetingRooms MeetingRooms
     * @return 结果
     */
    @Override
    public int insertMeetingRooms(MeetingRooms meetingRooms)
    {
        meetingRooms.setCreateTime(DateUtils.getNowDate());
        return meetingRoomsMapper.insertMeetingRooms(meetingRooms);
    }

    /**
     * 修改MeetingRooms
     * 
     * @param meetingRooms MeetingRooms
     * @return 结果
     */
    @Override
    public int updateMeetingRooms(MeetingRooms meetingRooms)
    {
        meetingRooms.setUpdateTime(DateUtils.getNowDate());
        return meetingRoomsMapper.updateMeetingRooms(meetingRooms);
    }

    /**
     * 批量删除MeetingRooms
     * 
     * @param roomIds 需要删除的MeetingRooms主键
     * @return 结果
     */
    @Override
    public int deleteMeetingRoomsByRoomIds(Long[] roomIds)
    {
        return meetingRoomsMapper.deleteMeetingRoomsByRoomIds(roomIds);
    }

    /**
     * 删除MeetingRooms信息
     * 
     * @param roomId MeetingRooms主键
     * @return 结果
     */
    @Override
    public int deleteMeetingRoomsByRoomId(Long roomId)
    {
        return meetingRoomsMapper.deleteMeetingRoomsByRoomId(roomId);
    }
}
