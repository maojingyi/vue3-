package com.ruoyi.supervisionproject.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * SupervisionProject对象 Supervision_Project
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public class SupervisionProject extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 督办编号 */
    private Long supervisoryId;

    /** 督办事项 */
    @Excel(name = "督办事项")
    private String supervisoryName;

    /** 督办依据  */
    @Excel(name = "督办依据 ")
    private String supervisoryBasis;

    /** 备注 */
    @Excel(name = "备注")
    private String note;

    /** 办理要求 */
    @Excel(name = "办理要求")
    private String requirements;

    /** 办公室联系人 */
    @Excel(name = "办公室联系人")
    private String officeContact;

    /** 办公室联系人电话  */
    @Excel(name = "办公室联系人电话 ")
    private String phoneNumber;

    /** 立项时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "立项时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date startDate;

    /** 落实时限 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "落实时限", width = 30, dateFormat = "yyyy-MM-dd")
    private Date deadline;

    /** 主办单位 */
    @Excel(name = "主办单位")
    private String hostDepartment;

    /** 主办单位联系人 */
    @Excel(name = "主办单位联系人")
    private String contactInfo;

    /** 主办部门主任室意见 */
    @Excel(name = "主办部门主任室意见")
    private String directorApproval;

    /** 协办单位 */
    @Excel(name = "协办单位")
    private String cooperationDepartment;

    /** 办公室立项意见 */
    @Excel(name = "办公室立项意见")
    private String officeApproval;

    /** 督办分类 */
    @Excel(name = "督办分类")
    private String category;

    /** 反馈时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "反馈时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date feedbackdate;

    /** 办理进度 */
    @Excel(name = "办理进度")
    private String progress;

    /** 是否办结 */
    @Excel(name = "是否办结")
    private Integer isCompleted;

    /** 附件 */
    @Excel(name = "附件")
    private String attachment;

    /** 评估 */
    @Excel(name = "评估")
    private String evaluation;

    /** 办公室初审意见 */
    @Excel(name = "办公室初审意见")
    private String officeReview;

    /** 行领导评估 */
    @Excel(name = "行领导评估")
    private String leaderEvaluation;

    /** 行领导意见 */
    @Excel(name = "行领导意见")
    private String leaderComment;

    /** 主办单位联系人电话 */
    @Excel(name = "主办单位联系人电话")
    private String contactTel;

    public void setSupervisoryId(Long supervisoryId) 
    {
        this.supervisoryId = supervisoryId;
    }

    public Long getSupervisoryId() 
    {
        return supervisoryId;
    }
    public void setSupervisoryName(String supervisoryName) 
    {
        this.supervisoryName = supervisoryName;
    }

    public String getSupervisoryName() 
    {
        return supervisoryName;
    }
    public void setSupervisoryBasis(String supervisoryBasis) 
    {
        this.supervisoryBasis = supervisoryBasis;
    }

    public String getSupervisoryBasis() 
    {
        return supervisoryBasis;
    }
    public void setNote(String note) 
    {
        this.note = note;
    }

    public String getNote() 
    {
        return note;
    }
    public void setRequirements(String requirements) 
    {
        this.requirements = requirements;
    }

    public String getRequirements() 
    {
        return requirements;
    }
    public void setOfficeContact(String officeContact) 
    {
        this.officeContact = officeContact;
    }

    public String getOfficeContact() 
    {
        return officeContact;
    }
    public void setPhoneNumber(String phoneNumber) 
    {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneNumber() 
    {
        return phoneNumber;
    }
    public void setStartDate(Date startDate) 
    {
        this.startDate = startDate;
    }

    public Date getStartDate() 
    {
        return startDate;
    }
    public void setDeadline(Date deadline) 
    {
        this.deadline = deadline;
    }

    public Date getDeadline() 
    {
        return deadline;
    }
    public void setHostDepartment(String hostDepartment) 
    {
        this.hostDepartment = hostDepartment;
    }

    public String getHostDepartment() 
    {
        return hostDepartment;
    }
    public void setContactInfo(String contactInfo) 
    {
        this.contactInfo = contactInfo;
    }

    public String getContactInfo() 
    {
        return contactInfo;
    }
    public void setDirectorApproval(String directorApproval) 
    {
        this.directorApproval = directorApproval;
    }

    public String getDirectorApproval() 
    {
        return directorApproval;
    }
    public void setCooperationDepartment(String cooperationDepartment) 
    {
        this.cooperationDepartment = cooperationDepartment;
    }

    public String getCooperationDepartment() 
    {
        return cooperationDepartment;
    }
    public void setOfficeApproval(String officeApproval) 
    {
        this.officeApproval = officeApproval;
    }

    public String getOfficeApproval() 
    {
        return officeApproval;
    }
    public void setCategory(String category) 
    {
        this.category = category;
    }

    public String getCategory() 
    {
        return category;
    }
    public void setFeedbackdate(Date feedbackdate) 
    {
        this.feedbackdate = feedbackdate;
    }

    public Date getFeedbackdate() 
    {
        return feedbackdate;
    }
    public void setProgress(String progress) 
    {
        this.progress = progress;
    }

    public String getProgress() 
    {
        return progress;
    }
    public void setIsCompleted(Integer isCompleted) 
    {
        this.isCompleted = isCompleted;
    }

    public Integer getIsCompleted() 
    {
        return isCompleted;
    }
    public void setAttachment(String attachment) 
    {
        this.attachment = attachment;
    }

    public String getAttachment() 
    {
        return attachment;
    }
    public void setEvaluation(String evaluation) 
    {
        this.evaluation = evaluation;
    }

    public String getEvaluation() 
    {
        return evaluation;
    }
    public void setOfficeReview(String officeReview) 
    {
        this.officeReview = officeReview;
    }

    public String getOfficeReview() 
    {
        return officeReview;
    }
    public void setLeaderEvaluation(String leaderEvaluation) 
    {
        this.leaderEvaluation = leaderEvaluation;
    }

    public String getLeaderEvaluation() 
    {
        return leaderEvaluation;
    }
    public void setLeaderComment(String leaderComment) 
    {
        this.leaderComment = leaderComment;
    }

    public String getLeaderComment() 
    {
        return leaderComment;
    }
    public void setContactTel(String contactTel) 
    {
        this.contactTel = contactTel;
    }

    public String getContactTel() 
    {
        return contactTel;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("supervisoryId", getSupervisoryId())
            .append("supervisoryName", getSupervisoryName())
            .append("supervisoryBasis", getSupervisoryBasis())
            .append("note", getNote())
            .append("requirements", getRequirements())
            .append("officeContact", getOfficeContact())
            .append("phoneNumber", getPhoneNumber())
            .append("startDate", getStartDate())
            .append("deadline", getDeadline())
            .append("hostDepartment", getHostDepartment())
            .append("contactInfo", getContactInfo())
            .append("directorApproval", getDirectorApproval())
            .append("cooperationDepartment", getCooperationDepartment())
            .append("officeApproval", getOfficeApproval())
            .append("category", getCategory())
            .append("feedbackdate", getFeedbackdate())
            .append("progress", getProgress())
            .append("isCompleted", getIsCompleted())
            .append("attachment", getAttachment())
            .append("evaluation", getEvaluation())
            .append("officeReview", getOfficeReview())
            .append("leaderEvaluation", getLeaderEvaluation())
            .append("leaderComment", getLeaderComment())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .append("contactTel", getContactTel())
            .toString();
    }
}
