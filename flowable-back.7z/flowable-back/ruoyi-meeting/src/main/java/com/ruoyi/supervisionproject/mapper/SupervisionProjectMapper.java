package com.ruoyi.supervisionproject.mapper;

import java.util.List;
import com.ruoyi.supervisionproject.domain.SupervisionProject;

/**
 * SupervisionProjectMapper接口
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
public interface SupervisionProjectMapper 
{
    /**
     * 查询SupervisionProject
     * 
     * @param supervisoryId SupervisionProject主键
     * @return SupervisionProject
     */
    public SupervisionProject selectSupervisionProjectBySupervisoryId(Long supervisoryId);

    /**
     * 查询SupervisionProject列表
     * 
     * @param supervisionProject SupervisionProject
     * @return SupervisionProject集合
     */
    public List<SupervisionProject> selectSupervisionProjectList(SupervisionProject supervisionProject);

    /**
     * 新增SupervisionProject
     * 
     * @param supervisionProject SupervisionProject
     * @return 结果
     */
    public int insertSupervisionProject(SupervisionProject supervisionProject);

    /**
     * 修改SupervisionProject
     * 
     * @param supervisionProject SupervisionProject
     * @return 结果
     */
    public int updateSupervisionProject(SupervisionProject supervisionProject);

    /**
     * 删除SupervisionProject
     * 
     * @param supervisoryId SupervisionProject主键
     * @return 结果
     */
    public int deleteSupervisionProjectBySupervisoryId(Long supervisoryId);

    /**
     * 批量删除SupervisionProject
     * 
     * @param supervisoryIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteSupervisionProjectBySupervisoryIds(Long[] supervisoryIds);
}
