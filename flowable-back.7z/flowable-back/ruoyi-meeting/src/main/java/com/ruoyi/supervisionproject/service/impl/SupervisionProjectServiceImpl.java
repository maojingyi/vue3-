package com.ruoyi.supervisionproject.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.supervisionproject.mapper.SupervisionProjectMapper;
import com.ruoyi.supervisionproject.domain.SupervisionProject;
import com.ruoyi.supervisionproject.service.ISupervisionProjectService;

/**
 * SupervisionProjectService业务层处理
 * 
 * @author ruoyi
 * @date 2023-09-25
 */
@Service
public class SupervisionProjectServiceImpl implements ISupervisionProjectService 
{
    @Autowired
    private SupervisionProjectMapper supervisionProjectMapper;

    /**
     * 查询SupervisionProject
     * 
     * @param supervisoryId SupervisionProject主键
     * @return SupervisionProject
     */
    @Override
    public SupervisionProject selectSupervisionProjectBySupervisoryId(Long supervisoryId)
    {
        return supervisionProjectMapper.selectSupervisionProjectBySupervisoryId(supervisoryId);
    }

    /**
     * 查询SupervisionProject列表
     * 
     * @param supervisionProject SupervisionProject
     * @return SupervisionProject
     */
    @Override
    public List<SupervisionProject> selectSupervisionProjectList(SupervisionProject supervisionProject)
    {
        return supervisionProjectMapper.selectSupervisionProjectList(supervisionProject);
    }

    /**
     * 新增SupervisionProject
     * 
     * @param supervisionProject SupervisionProject
     * @return 结果
     */
    @Override
    public int insertSupervisionProject(SupervisionProject supervisionProject)
    {
        supervisionProject.setCreateTime(DateUtils.getNowDate());
        return supervisionProjectMapper.insertSupervisionProject(supervisionProject);
    }

    /**
     * 修改SupervisionProject
     * 
     * @param supervisionProject SupervisionProject
     * @return 结果
     */
    @Override
    public int updateSupervisionProject(SupervisionProject supervisionProject)
    {
        supervisionProject.setUpdateTime(DateUtils.getNowDate());
        return supervisionProjectMapper.updateSupervisionProject(supervisionProject);
    }

    /**
     * 批量删除SupervisionProject
     * 
     * @param supervisoryIds 需要删除的SupervisionProject主键
     * @return 结果
     */
    @Override
    public int deleteSupervisionProjectBySupervisoryIds(Long[] supervisoryIds)
    {
        return supervisionProjectMapper.deleteSupervisionProjectBySupervisoryIds(supervisoryIds);
    }

    /**
     * 删除SupervisionProject信息
     * 
     * @param supervisoryId SupervisionProject主键
     * @return 结果
     */
    @Override
    public int deleteSupervisionProjectBySupervisoryId(Long supervisoryId)
    {
        return supervisionProjectMapper.deleteSupervisionProjectBySupervisoryId(supervisoryId);
    }
}
